/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vendingmachine.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;
import com.vendingmachine.model.Item;
import com.vendingmachine.repository.VendingMachineRepository;

/**
 *
 * @author Nazeer
 */
@Repository
public class ItemDaoDBImpl implements ItemDao {
	@Autowired
	VendingMachineRepository vendingMachineRepository;

	@Override
	public Item addItem(Item item) {
		Item it = vendingMachineRepository.save(item);
		return it;
	}

	@Override
	public Item getItemById(int id) {
		try {
			return vendingMachineRepository.findOne(Long.valueOf(id));
		} catch (EmptyResultDataAccessException ex) {
			return null;
		}
	}

	@Override
	public List<Item> getAllItems() {

		return vendingMachineRepository.findAll();
	}

	@Override
	public void updateItem(Item item) {
		vendingMachineRepository.save(item);
	}

	@Override
	public void removeItem(int id) {
		Item itm = new Item();
		itm.setId(id);
		vendingMachineRepository.delete(itm);
	}

	@Override
	public List<Item> searchItemsByName(String name) {

		return vendingMachineRepository.findByName(name);
	}

}
