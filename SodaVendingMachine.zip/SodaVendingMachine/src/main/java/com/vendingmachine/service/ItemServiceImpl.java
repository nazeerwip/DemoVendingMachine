/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vendingmachine.service;

import com.vendingmachine.dao.ItemDao;
import com.vendingmachine.model.Item;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Nazeer
 */
@Component
public class ItemServiceImpl implements ItemService {
	@Autowired
	ItemDao itemDao;

	@Override
	@Transactional
	public Item addItem(Item item) {
		Item items = itemDao.addItem(item);
		return items;
	}

	@Override
	@Transactional
	public Item getItemById(int id) {
		Item item = itemDao.getItemById(id);
		return item;
	}

	@Override
	@Transactional
	public List<Item> getAllItems() {
		List<Item> itemsList = itemDao.getAllItems();
		return itemsList;
	}

	@Override
	@Transactional
	public void updateItem(Item item) {
		itemDao.updateItem(item);
	}

	@Override
	@Transactional
	public void removeItem(int id) {
		itemDao.removeItem(id);
	}

	@Override
	@Transactional
	public List<Item> searchItemsByName(String name) {
		List<Item> itemsList = itemDao.searchItemsByName(name);
		return itemsList;
	}

}
