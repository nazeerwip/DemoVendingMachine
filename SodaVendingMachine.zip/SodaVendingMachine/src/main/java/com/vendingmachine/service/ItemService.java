/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vendingmachine.service;

import java.util.List;

import com.vendingmachine.model.Item;

/**
 *
 * @author Nazeer
 */
public interface ItemService {

	public Item addItem(Item item);

	public Item getItemById(int id);

	public List<Item> getAllItems();

	public void updateItem(Item item);

	public void removeItem(int id);

	public List<Item> searchItemsByName(String name);

}
