package com.vendingmachine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages= {"com.vendingmachine"})
public class SodaVendingMachineApplication {

	public static void main(String[] args) {
		SpringApplication.run(SodaVendingMachineApplication.class, args);
	}

}
